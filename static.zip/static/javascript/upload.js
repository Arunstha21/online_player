var form = document.getElementById('upload-form');
var progress = document.getElementById('upload-progress');
var percentage = document.getElementById('upload-percentage');

form.onsubmit = function (event) {
    event.preventDefault();
    var file = document.querySelector('#file').files[0];
    var formData = new FormData();
    formData.append('file', file);

    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/upload', true);

    xhr.upload.onprogress = function (e) {
        if (e.lengthComputable) {
            var percentComplete = (e.loaded / e.total) * 100;
            progress.style.width = percentComplete + '%';
            percentage.innerHTML = percentComplete.toFixed(2) + '%';
        }
    };

    xhr.onload = function () {
        if (xhr.status === 200) {
            var response = JSON.parse(xhr.responseText);
            alert(response.message);
        } else {
            alert('Error uploading file');
        }
    };

    xhr.send(formData);
};
